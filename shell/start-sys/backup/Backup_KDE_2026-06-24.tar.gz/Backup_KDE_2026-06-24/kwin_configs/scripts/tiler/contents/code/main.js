/*
 * Name:         Tiler
 * Description:  An easy-to-use Kwin script for half- and third-screen window tiling.
 *               Supports gaps between windows.
 *               Useful for ultrawide monitors.
 *               Default shortcuts require a number keypad, but can be manually reassigned if needed.
 *               Plasma 6 compliant.
 * Author:       Johnny Honu (johnny.honu@gmail.com)
 * Date:         2024-04-06
 * Version:      1.1
 * License:      GPLv3
*/

// USE THIS COMMAND TO CLEAN UP THE SHORTCUTS MENU IN KDE PLASMA SYSTEM SETTINGS IF NECESSARY
// qdbus org.kde.kglobalaccel /component/kwin org.kde.kglobalaccel.Component.cleanUp

// DEFINE SHORTCUTS
var tileShortcuts = [

    // THIRDS (Meta+Num+digit)
    ["TileLowerLeftThird",    "Tile to LOWER LEFT third",    "Meta+Num+1",  3, 2, 1, 2, 1, 1],
    ["TileLowerMiddleThird",  "Tile to LOWER MIDDLE third",  "Meta+Num+2",  3, 2, 2, 2, 1, 1],
    ["TileLowerRightThird",   "Tile to LOWER RIGHT third",   "Meta+Num+3",  3, 2, 3, 2, 1, 1],
    ["TileLeftThird",         "Tile to LEFT third",          "Meta+Num+4",  3, 1, 1, 1, 1, 1],
    ["TileMiddleThird",       "Tile to MIDDLE third",        "Meta+Num+5",  3, 1, 2, 1, 1, 1],
    ["TileRightThird",        "Tile to RIGHT third",         "Meta+Num+6",  3, 1, 3, 1, 1, 1],
    ["TileUpperLeftThird",    "Tile to UPPER LEFT third",    "Meta+Num+7",  3, 2, 1, 1, 1, 1],
    ["TileUpperMiddleThird",  "Tile to UPPER MIDDLE third",  "Meta+Num+8",  3, 2, 2, 1, 1, 1],
    ["TileUpperRightThird",   "Tile to UPPER RIGHT third",   "Meta+Num+9",  3, 2, 3, 1, 1, 1],

    // THIRDS, WITH THE MIDDLE THIRD WIDER THAN THE SIDES (Meta+Ctrl+Num+digit)
    ["TileLowerLeftThirdWideMiddle",    "Tile to LOWER LEFT third (wide middle)",    "Meta+Ctrl+Num+1",  4, 2, 1, 2, 1, 1],
    ["TileLowerMiddleThirdWideMiddle",  "Tile to LOWER MIDDLE third (wide middle)",  "Meta+Ctrl+Num+2",  4, 2, 2, 2, 2, 1],
    ["TileLowerRightThirdWideMiddle",   "Tile to LOWER RIGHT third (wide middle)",   "Meta+Ctrl+Num+3",  4, 2, 4, 2, 1, 1],
    ["TileLeftThirdWideMiddle",         "Tile to LEFT third (wide middle)",          "Meta+Ctrl+Num+4",  4, 1, 1, 1, 1, 1],
    ["TileMiddleThirdWideMiddle",       "Tile to MIDDLE third (wide middle)",        "Meta+Ctrl+Num+5",  4, 1, 2, 1, 2, 1],
    ["TileRightThirdWideMiddle",        "Tile to RIGHT third (wide middle)",         "Meta+Ctrl+Num+6",  4, 1, 4, 1, 1, 1],
    ["TileUpperLeftThirdWideMiddle",    "Tile to UPPER LEFT third (wide middle)",    "Meta+Ctrl+Num+7",  4, 2, 1, 1, 1, 1],
    ["TileUpperMiddleThirdWideMiddle",  "Tile to UPPER MIDDLE third (wide middle)",  "Meta+Ctrl+Num+8",  4, 2, 2, 1, 2, 1],
    ["TileUpperRightThirdWideMiddle",   "Tile to UPPER RIGHT third (wide middle)",   "Meta+Ctrl+Num+9",  4, 2, 4, 1, 1, 1],

    // HALFS & QUARTERS (Meta+Alt+Num+digit)
    ["TileLowerLeftQuarter",   "Tile to LOWER LEFT quarter",   "Meta+Alt+Num+1",   2, 2, 1, 2, 1, 1],
    ["TileLowerHalf",          "Tile to LOWER half",           "Meta+Alt+Num+2",   1, 2, 1, 2, 1, 1],
    ["TileLowerRightQuarter",  "Tile to LOWER RIGHT quarter",  "Meta+Alt+Num+3",   2, 2, 2, 2, 1, 1],
    ["TileLeftHalf",           "Tile to LEFT half",            "Meta+Alt+Num+4",   2, 1, 1, 1, 1, 1],
    ["TileRightHalf",          "Tile to RIGHT half",           "Meta+Alt+Num+6",   2, 1, 2, 1, 1, 1],
    ["TileUpperLeftQuarter",   "Tile to UPPER LEFT quarter",   "Meta+Alt+Num+7",   2, 2, 1, 1, 1, 1],
    ["TileUpperHalf",          "Tile to UPPER half",           "Meta+Alt+Num+8",   1, 2, 1, 1, 1, 1],
    ["TileUpperRightQuarter",  "Tile to UPPER RIGHT quarter",  "Meta+Alt+Num+9",   2, 2, 2, 1, 1, 1]

];

// WINDOW TILE FUNCTION
function tile(workspace, gridW, gridH, winX, winY, winW, winH) {

    // GET WORKSPACE GEOMETRY
    var ws = workspace.clientArea(KWin.PlacementArea, workspace.activeScreen, workspace.currentDesktop);

    // CALCULATE NEW WORKSPACE TO ACCOUNT FOR GAPS
    var gap = readConfig("Gap", 0);
    var wsX = ws.x + gap;
    var wsY = ws.y + gap;
    var wsW = ws.width - gap;
    var wsH = ws.height - gap;

    // CALCULATE NEW WIDTH
    var newW = Math.trunc(wsW / gridW) * winW - gap;
    var modW = wsW % gridW;
    var addW = modW - winX + 1;
    if (addW < 0) addW = 0; else if (addW > winW) addW = winW;
    newW += addW;

    // CALCULATE NEW HEIGHT
    var newH = Math.trunc(wsH / gridH) * winH - gap;
    var modH = wsH % gridH;
    var addH = modH - winY + 1;
    if (addH < 0) addH = 0; else if (addH > winH) addH = winH;
    newH += addH;

    // CALCULATE NEW X
    var newX = Math.trunc(wsW / gridW) * (winX - 1) + wsX;
    var addX = winX - 1;
    if (addX > modW) addX = modW;
    newX += addX;

    // CALCULATE NEW Y
    var newY = Math.trunc(wsH / gridH) * (winY - 1) + wsY;
    var addY = winY - 1;
    if (addY > modH) addY = modH;
    newY += addY;

    // TILE THE WINDOW
    var w = workspace.activeWindow;
    if (w.normalWindow === true && w.managed === true && w.fullScreen === true) w.fullScreen = false;
    if (w.normalWindow === true && w.managed === true && w.resizeable === true && w.moveable === true) {
        w.setMaximize(false, false);
        w.frameGeometry = { x: newX, y: newY, width: newW, height: newH };
        workspace.raiseWindow(w);
    }

}

// FUNCTION FOR MAKING TILE SHORTCUTS
function makeTileShortcut(array) {
    registerShortcut(array[0], array[1], array[2], function () {
        tile(workspace, array[3], array[4], array[5], array[6], array[7], array[8]);
    });
}

// REGISTER EACH SHORTCUTS IN tileShortcuts ARRAY
tileShortcuts.forEach(makeTileShortcut);
